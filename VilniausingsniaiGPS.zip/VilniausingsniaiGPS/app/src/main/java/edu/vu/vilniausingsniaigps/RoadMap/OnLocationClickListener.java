package edu.vu.vilniausingsniaigps.RoadMap;

public interface OnLocationClickListener {
    void onLocationClick(LocationModel location);
}
