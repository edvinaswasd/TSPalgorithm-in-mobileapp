package edu.vu.vilniausingsniaigps.RoadMap;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.vu.vilniausingsniaigps.R;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.ViewHolder> {

    private List<LocationModel> locationList;
    private OnLocationClickListener onLocationClickListener;
    public LocationAdapter(List<LocationModel> locationList,
                           OnLocationClickListener onLocationClickListener) {
        this.locationList = locationList;
        this.onLocationClickListener = onLocationClickListener;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_location, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        LocationModel location = locationList.get(position);
        holder.txtLocation.setText(location.getTitle());

        holder.cardvieqw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onLocationClickListener.onLocationClick(locationList.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return locationList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtLocation;
        CardView cardvieqw;
        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            txtLocation = itemView.findViewById(R.id.txtLocation);
            cardvieqw = itemView.findViewById(R.id.cardvieqw);

        }
    }
}
