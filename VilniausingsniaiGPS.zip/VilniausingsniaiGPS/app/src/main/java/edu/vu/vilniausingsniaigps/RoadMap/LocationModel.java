package edu.vu.vilniausingsniaigps.RoadMap;

import com.google.android.gms.maps.model.LatLng;

public class LocationModel {
    LatLng latLng;
    String title;

    public LocationModel(LatLng latLng, String title) {
        this.latLng = latLng;
        this.title = title;
    }

    public LatLng getLatLng() {
        return latLng;
    }

    public String getTitle() {
        return title;
    }
}
