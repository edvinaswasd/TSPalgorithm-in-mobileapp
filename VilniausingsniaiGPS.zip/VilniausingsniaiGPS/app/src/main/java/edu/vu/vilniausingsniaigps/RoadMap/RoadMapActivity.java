package edu.vu.vilniausingsniaigps.RoadMap;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import edu.vu.vilniausingsniaigps.R;

public class RoadMapActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.OnConnectionFailedListener, RoutingListener,OnLocationClickListener {

    //google map object
    private GoogleMap mMap;

    //current and destination location objects
    Location myLocation=null;
    Location destinationLocation=null;
    protected LatLng start=null;
    LatLng lastLatLng=null;
    protected LatLng end=null;

    //to get location permissions.
    private final static int LOCATION_REQUEST_CODE = 23;
    boolean locationPermission=false;

    //polyline object
    private List<Polyline> polylines=null;
    ArrayList<LocationModel> locationModelArrayList;
    List<String> colorList;

    LocationModel locationModel;
    AlertDialog alertDialog;
    boolean firstTime=true;
    private List<Integer> generateUniqueNumbers(int count) {
        List<Integer> uniqueNumbers = new ArrayList<>();
        List<Integer> availableNumbers = new ArrayList<>();

        // Başlangıçta tüm sayıları kullanılabilir sayılar listesine ekle
        for (int i = 0; i <= 14; i++) {
            availableNumbers.add(i);
        }

        Random random = new Random();
        for (int i = 0; i < count; i++) {
            // Kullanılabilir sayılardan rastgele bir sayı seç
            int randomIndex = random.nextInt(availableNumbers.size());
            int randomNumber = availableNumbers.get(randomIndex);

            // Benzersiz sayıları listeye ekle
            uniqueNumbers.add(randomNumber);

            // Kullanılan sayıyı kullanılabilir sayılar listesinden kaldır
            availableNumbers.remove(randomIndex);

            // Eğer kullanılabilir sayılar listesi boş ise, tekrar başa dön
            if (availableNumbers.isEmpty()) {
                availableNumbers.addAll(uniqueNumbers);
            }
        }

        return uniqueNumbers;
    }
    private void showLocationListDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(RoadMapActivity.this);

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_location_list, null);
        builder.setView(dialogView);

        RecyclerView recyclerViewLocations = dialogView.findViewById(R.id.recyclerViewLocations);
        recyclerViewLocations.setLayoutManager(new LinearLayoutManager(RoadMapActivity.this));

        LocationAdapter locationAdapter = new LocationAdapter(locationModelArrayList, this);
        recyclerViewLocations.setAdapter(locationAdapter);

          alertDialog = builder.create(); // AlertDialog oluşturulur

// btnClose'ye tıklama olayı atanır
        dialogView.findViewById(R.id.btnClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss(); // Dialog kapatılır
            }
        });

        alertDialog.show(); // AlertDialog gösterilir




    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roadmap);
        locationModelArrayList=new ArrayList<>();

        locationModelArrayList.add(new LocationModel(new LatLng(54.683108758799776, 25.293007539879323),"Šv.Onos Bažnyčia"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.698845273414136, 25.303313482207066),"Tuskulėnų dvaras"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.658970224662355, 25.286113753367914),"Naujininkų apžvalgos kalva"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.746971037248436, 25.292387465816216),"Verkių rūmų apžvalgos aikštelė "));
        locationModelArrayList.add(new LocationModel(new LatLng(54.70143127463738, 25.19388195522699),"Pilaitės vėjo malūnas"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.69223096901036, 25.35296752638968),"Pučkorių atodanga"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.66785508371912, 25.228885469284506),"Neries apžvalgos terasa"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.78789356866545, 25.338530755232437),"Balsio ežero regykla"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.67930895821123, 25.277934166362723),"MO Muziejus"));
        locationModelArrayList.add(new LocationModel(new LatLng(54.63024914908841, 25.27860958482735),"Vilniaus oro uosto stebėjimo aikštelė"));
        //request location permission.
        requestPermision();
          colorList=new ArrayList<>();

        colorList.add("#FF0000"); // Red
        colorList.add("#00FF00"); // Green
        colorList.add("#0000FF"); // Blue
        colorList.add("#FFA500"); // Orange
        colorList.add("#800080"); // Purple
        colorList.add("#008000"); // Dark Green
        colorList.add("#000080"); // Dark Blue
        colorList.add("#800000"); // Maroon
        colorList.add("#008080"); // Teal
        colorList.add("#FF4500"); // Orange Red
        colorList.add("#FF1493"); // Deep Pink
        colorList.add("#9400D3"); // Dark Violet
        colorList.add("#FFD700"); // Gold
        colorList.add("#A52A2A"); // Brown

        //init google map fragment to show map.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        findViewById(R.id.floatingActionButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            showLocationListDialog();
            }
        });

        findViewById(R.id.floatingActionButtonClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mMap.clear();
                lastLatLng=null;
            }
        });
    }

    private void requestPermision()
    {
        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_REQUEST_CODE);
        }
        else{
            locationPermission=true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case LOCATION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //if permission granted.
                    locationPermission=true;
                    getMyLocation();

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
        }
    }

    //to get user location
    private void getMyLocation(){
        mMap.setMyLocationEnabled(true);
        mMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location location) {

                myLocation=location;
                if (firstTime){
                    firstTime=false;
                    LatLng ltlng=new LatLng(location.getLatitude(),location.getLongitude());
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(
                            ltlng, 16f);
                    mMap.animateCamera(cameraUpdate);
                }

            }
        });



    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if(locationPermission) {
            getMyLocation();
        }
        CustomInfoWindowAdapter infoWindowAdapter = new CustomInfoWindowAdapter(this);
        mMap.setInfoWindowAdapter(infoWindowAdapter);

    }


    // function to find Routes.
    public void findRoutes(LatLng Start, LatLng End)
    {
        if(Start==null || End==null) {
            Toast.makeText(RoadMapActivity.this,"Unable to get location", Toast.LENGTH_LONG).show();
        }
        else
        {

            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(Start, End)
                    .key("AIzaSyAARCVkCUMcpYyV5UUplGxz1BiP9-XBOpA")  //also define your api key here.
                    .build();
            routing.execute();
        }
    }

    //Routing call back functions.
    @Override
    public void onRoutingFailure(RouteException e) {
        Toast.makeText(this, "Please choose a different location or try again later.",
                Toast.LENGTH_LONG).show();

    }

    @Override
    public void onRoutingStart() {
        Toast.makeText(this, "Please wait, the route is being created.", Toast.LENGTH_SHORT).show();
    }

    //If Route finding success..
    @Override
    public void onRoutingSuccess(ArrayList<Route> route, int shortestRouteIndex) {
        PolylineOptions polyOptions = new PolylineOptions();
        LatLng polylineStartLatLng = null;
        LatLng polylineEndLatLng = null;

        polylines = new ArrayList<>();
//Add route(s) to map using polyline
        for (int i = 0; i < route.size(); i++) {
            if (i == shortestRouteIndex) {
                polyOptions.color(Color.parseColor(colorList.get(generateUniqueNumbers(14).get(0))));
                polyOptions.width(10);
                polyOptions.addAll(route.get(shortestRouteIndex).getPoints());
                Polyline polyline = mMap.addPolyline(polyOptions);
                polylineStartLatLng = polyline.getPoints().get(0);
                int k = polyline.getPoints().size();
                polylineEndLatLng = polyline.getPoints().get(k - 1);
                polylines.add(polyline);
            } else {

            }
        }

//Add Marker to route starting point
        MarkerOptions startMarker = new MarkerOptions();
        startMarker.position(polylineStartLatLng);
        startMarker.title("Atskaitos taškas");
        startMarker.snippet("Atskaitos taškas"); // Title'ı snippet olarak ayarla

        mMap.addMarker(startMarker);

//Add Marker to route endpoint
        MarkerOptions endMarker = new MarkerOptions();
        endMarker.position(polylineEndLatLng);
        endMarker.title(locationModel.getTitle());
        endMarker.snippet(locationModel.getTitle()); // Title'ı snippet olarak ayarla

        mMap.addMarker(endMarker);

        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(polylineEndLatLng, 16f);
        mMap.animateCamera(cameraUpdate);

        Toast.makeText(this,
                locationModel.getTitle() + ": " + locationModel.getLatLng().latitude + "," +
                        locationModel.getLatLng().longitude + " Added to the Route!",
                Toast.LENGTH_LONG).show();

    }

    @Override
    public void onRoutingCancelled() {
        findRoutes(start,end);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        findRoutes(start,end);

    }

    @Override
    public void onLocationClick(LocationModel location) {
        locationModel=location;
        if (alertDialog.isShowing()){alertDialog.dismiss();}

        if (lastLatLng==null){
            start=new LatLng(myLocation.getLatitude(),myLocation.getLongitude());
            findRoutes(start,location.getLatLng());
            lastLatLng=location.getLatLng();
        }else {
            findRoutes(lastLatLng,location.getLatLng());
            lastLatLng=location.getLatLng();
        }


    }
}